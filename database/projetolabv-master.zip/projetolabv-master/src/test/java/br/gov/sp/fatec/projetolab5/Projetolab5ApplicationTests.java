package br.gov.sp.fatec.projetolab5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Projetolab5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
