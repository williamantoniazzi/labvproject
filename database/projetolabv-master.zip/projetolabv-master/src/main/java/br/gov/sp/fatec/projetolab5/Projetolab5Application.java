package br.gov.sp.fatec.projetolab5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Projetolab5Application {

	public static void main(String[] args) {
		SpringApplication.run(Projetolab5Application.class, args);
	}

}
