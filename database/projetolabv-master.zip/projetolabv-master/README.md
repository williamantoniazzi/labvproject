# Projeto da disciplina Laboratório de Desenvolvimento em Banco de Dados V

## Para executar: 
* mvn spring-boot:run

## Caso tenha algum erro envolvendo versão de Java:
* mvn clean

## Para executar testes: 
* mvn test

## Para executar testes e gerar relatório: 
* mvn test jacoco:report

Para visualizar os testes, abra no navegador o arquivo "index.html" em "/target/site/jacoco"

